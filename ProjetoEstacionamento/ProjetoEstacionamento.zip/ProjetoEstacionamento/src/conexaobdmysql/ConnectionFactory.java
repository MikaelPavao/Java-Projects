/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexaobdmysql;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *  CLASSE RESPONSÁVEL PELA ABERTURA E FECHAMENTO DA CONEXÃO COM O BANCO DE DADOS MySQL.  
 * @author Mikael
 */
public class ConnectionFactory {

    private final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private final String URL = "jdbc:mysql://localhost:3306/estacionamento";
    private final String USER = "root";
    private final String PASSWORD = "";
    //MÉTODO RESPONSÁVEL PELA CONEXÃO COM O BANCO DE DADOS.
    public  Connection getConnection(){
        
        try {
            Class.forName(DRIVER);
            return DriverManager.getConnection(URL,USER,PASSWORD);
        } catch (ClassNotFoundException | SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro de conexão com o banco de dados \n" + ex);
            return null;
        }                
        
    }

    public  String getDRIVER() {
        return DRIVER;
    }

    public  String getURL() {
        return URL;
    }

    public  String getUSER() {
        return USER;
    }

    public  String getPASSWORD() {
        return PASSWORD;
    }
    //MÉTODOS closeConnection() SOBRECARREGADOS SÃO RESPONSÁVEIS PELO FECHAMENTO DA CONEXÃO COM O BANCO DE DADOS.
    public  void closeConnection(Connection cnx){
        
        if(cnx != null){
            try {
                cnx.close();
            } catch (SQLException ex) {
                Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, ex);
            }
        }           
    }
    
    public  void closeConnection(Connection cnx, PreparedStatement pstm){
        
        closeConnection(cnx);
            try {
                if(cnx != null){
                    pstm.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, ex);
            }   
    }
    
    public void closeConnection(Connection cnx, PreparedStatement pstm, ResultSet rst){
                
        closeConnection(cnx, pstm);
        
        
            try {
                if(cnx != null){
                    rst.close();
                }
            } catch (SQLException ex) {
                
                Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, ex);
            
            }            
    }    
}