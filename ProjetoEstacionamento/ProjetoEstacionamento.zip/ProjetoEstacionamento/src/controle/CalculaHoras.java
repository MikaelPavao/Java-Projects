/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import javax.swing.JOptionPane;

/**
 * CLASSE RESPONSÁVEL PELA CONVERSÃO DE DUAS STRING´S NO FORMATO DE HORAS E MINUTOS EX: "12:34" 
 * PARA UM VALOR INTEIRO COM O TOTAL DE HORAS SUBTRAINDO A HORA INICIAL DA HORA FINAL.
 * @author Mikael.
 */
public class CalculaHoras {
    private String horaInicial;
    private String horaFinal;   
    private long res;
        
    
    public CalculaHoras(){
           
    }
    /**
     * 
     * @param hrIni //Recebe a String com a hora inicial.
     * @param hrFin //Recebe a String com a hora final.
     * @return Retorna um inteiro
     */
    public int retonaQtdHoras(String hrIni,String hrFin){
        
        try{
                        
            this.horaInicial = hrIni;
            this.horaFinal = hrFin;


            //SEPARA AS STRING'S RECEBIDAS PELOS PARÂMETROS hrInicial e hrFinal,
            //EXTRAI SEPARADAMENTE AS HORAS DOS MINUTOS E NA SEQUÊNCIA CONVERTE O DADO PARA NÚMERO INTEIRO.

            String hrInicial = horaInicial.substring(0, 2);
            String minInicial = horaInicial.substring(3, 5);

            String hrFinal = horaFinal.substring(0, 2);
            String minFinal = horaFinal.substring(3, 5);

            int hr = Integer.parseInt(hrInicial);
            int min =Integer.parseInt(minInicial);

            int hr2 = Integer.parseInt(hrFinal);
            int min2 = Integer.parseInt(minFinal);

            //horaChegada QUE É DO TIPO LocalDateTime QUE RECEBE AS HORAS E MINUTOS DO MÉTODO of().
            LocalDateTime horaChegada;
            horaChegada = LocalDateTime.of(2021, 1, 1, hr, min);
            //horaSaida qQUE É DO TIPO LocalDateTime QUE RECEBE AS HORAS E MINUTOS DO MÉTODO of().
            LocalDateTime horaSaida;
            horaSaida = LocalDateTime.of(2021, 1, 1, hr2,min2);

            //CALCULA A DIFERENÇA EM MINUTOS ENTRE horaChegada E horaSaida E ARMAZENA NA VARIÁVEL resMin.
            res = ChronoUnit.HOURS.between(horaChegada, horaSaida);
                        
            //RETORNA O VALOR INTEIRO DO NÚMERO DE HORAS.            
            return (int)res;
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, "Um dos parâmetros \n está de entrada vazio");
            return 0;
        }
        
    
    }
    
     
     
}
