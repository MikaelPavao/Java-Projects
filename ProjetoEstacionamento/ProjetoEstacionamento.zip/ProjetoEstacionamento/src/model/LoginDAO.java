/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import conexaobdmysql.ConnectionFactory;
import controle.DadosEntrada;
import controle.DadosSaida;
import java.sql.*;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;


/**
 * CLASSE QUE REALIZA A MANIPULAÇÃO DOS DADOS DO BANCO DE DADOS INSERINDO, EDITANDO, EXCLUINDO E CONSULTANDO.
 * @author Mikael.
 */
public class LoginDAO {
    
    ConnectionFactory cn = new ConnectionFactory();
    
    //INSERE OS DADOS NA TABELA tbl_movimentacao VINDOS DA CLASSE DadosEntrada().
    public void insereDadosEntrada(DadosEntrada tf){
       
         Connection cnx = cn.getConnection();
        
        PreparedStatement pstm = null;
            try {
                pstm = cnx.prepareStatement("INSERT INTO tbl_movimentacao(placa,modelo,data_entrada,data_saida,hora_entrada, hora_saida, tempo,valor_pago) VALUES(?,?,?,?,?,?,?,?)");
                pstm.setString(1, tf.getPlaca());
                pstm.setString(2, tf.getModelo());
                pstm.setString(3, tf.getData());
                pstm.setString(4, tf.getDataSaida());
                pstm.setString(5, tf.getHoraChegada());
                pstm.setString(6, tf.getHoraSaida());
                pstm.setString(7, tf.getTempo());
                pstm.setDouble(8, tf.getValorPago());
                pstm.executeUpdate();
                
                JOptionPane.showMessageDialog(null, "Salvo com sucesso");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Erro no cadastro \n"+ ex );
            }finally{
                
                cn.closeConnection(cnx, pstm);
            }
    }
    
    //INSERE OS DADOS NA TABELA tbl_movimentacao_saida VINDOS DA CLASSE DadosEntrada().
    public void insereDadosSaida(DadosSaida tf){
       
         Connection cnx = cn.getConnection();
        
        PreparedStatement pstm = null;
            try {
                pstm = cnx.prepareStatement("INSERT INTO tbl_movimentacao_saida(placa,modelo,data_entrada,data_saida,hora_entrada, hora_saida, tempo,valor_pago) VALUES(?,?,?,?,?,?,?,?)");
                pstm.setString(1, tf.getPlaca());
                pstm.setString(2, tf.getModelo());
                pstm.setString(3, tf.getData());
                pstm.setString(4, tf.getDataSaida());
                pstm.setString(5, tf.getHoraChegada());
                pstm.setString(6, tf.getHoraSaida());
                pstm.setString(7, tf.getTempo());
                pstm.setDouble(8, tf.getValorPago());
                pstm.executeUpdate();
                
                
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Erro no cadastro \n" + ex );
            }finally{
                
                cn.closeConnection(cnx, pstm);
            }
    }
    
    //SELECIONA OS DADOS NA TABELA tbl_movimentacao.
    public List<DadosEntrada> selecionaDados() {
        
        Connection conleitura = cn.getConnection();
        PreparedStatement pstm = null;
        ResultSet rs = null;
        
        List<DadosEntrada> arrayDados = new ArrayList<>();        
        try{
        pstm = conleitura.prepareStatement("SELECT * FROM tbl_movimentacao");
        rs = pstm.executeQuery();
        
        while(rs.next()){
                DadosEntrada dadosLeitura = new DadosEntrada();
                
                dadosLeitura.setId(rs.getInt("id"));
                dadosLeitura.setPlaca(rs.getString("placa"));
                dadosLeitura.setModelo(rs.getString("modelo"));
                dadosLeitura.setData(rs.getString("data_entrada"));
                dadosLeitura.setDataSaida(rs.getString("data_saida"));
                dadosLeitura.setHoraChegada(rs.getString("hora_entrada"));
                dadosLeitura.setHoraSaida(rs.getString("hora_saida"));
                dadosLeitura.setTempo(rs.getString("tempo"));
                dadosLeitura.setValorPago(rs.getDouble("valor_pago"));
                
                arrayDados.add(dadosLeitura);
            }
        }catch(SQLException ex){
            
            JOptionPane.showMessageDialog(null,"Erro na consulta dos dados no banco de dados \n" + ex);
            
        }finally{
                cn.closeConnection(conleitura, pstm, rs);
            
        }
        return arrayDados;
        
    }
    
    //SELECIONA OS DADOS NA TABELA tbl_movimentacao_saida.
    public List<DadosSaida> selecionaDadosSaida() {
        
        Connection conleitura = cn.getConnection();
        PreparedStatement pstm = null;
        ResultSet rs = null;
        
        List<DadosSaida> arrayDados = new ArrayList<>();        
        try{
        pstm = conleitura.prepareStatement("SELECT * FROM tbl_movimentacao_saida");
        rs = pstm.executeQuery();
        
        while(rs.next()){
                DadosSaida dadosLeitura = new DadosSaida();
                
                dadosLeitura.setId(rs.getInt("id"));
                dadosLeitura.setPlaca(rs.getString("placa"));
                dadosLeitura.setModelo(rs.getString("modelo"));
                dadosLeitura.setData(rs.getString("data_entrada"));
                dadosLeitura.setDataSaida(rs.getString("data_saida"));
                dadosLeitura.setHoraChegada(rs.getString("hora_entrada"));
                dadosLeitura.setHoraSaida(rs.getString("hora_saida"));
                dadosLeitura.setTempo(rs.getString("tempo"));
                dadosLeitura.setValorPago(rs.getDouble("valor_pago"));
                
                arrayDados.add(dadosLeitura);
            }
        }catch(SQLException ex){
            
            JOptionPane.showMessageDialog(null,"Erro na consulta dos dados no banco de dados \n" + ex);
            
        }finally{
                cn.closeConnection(conleitura, pstm, rs);
            
        }
        return arrayDados;
        
    }
    
    //ALTERA OS DADOS DE PLACA E MODELO NA TABELA tbl_movimentacao.
    public void alteraDados(DadosEntrada tf){
       
        Connection cnx = cn.getConnection();
        PreparedStatement pstm = null;
            
            try {
                pstm = cnx.prepareStatement("UPDATE tbl_movimentacao SET placa = ?, modelo = ? WHERE id = ?");
                pstm.setString(1, tf.getPlaca());
                pstm.setString(2, tf.getModelo());
                pstm.setInt(3, tf.getId());
                pstm.executeUpdate();
                
                
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Erro na edição \n" + ex );
            }finally{
                
                cn.closeConnection(cnx, pstm);
            }
    }
    
    //ATUALIZA OS VALORES DE TEMPO E VALOR PAGO DA TABELA tbl_movimentacao QUANDO É SOLICITADA A SAÍDA DO VEÍCULO.
    public void alteraDadosSaida(DadosSaida tf){
       
        Connection cnx = cn.getConnection();
        PreparedStatement pstm = null;
            
            try {
                pstm = cnx.prepareStatement("UPDATE tbl_movimentacao SET valor_pago = ?, tempo = ? WHERE id = ?");
                pstm.setDouble(1, tf.getValorPago());
                pstm.setString(2, tf.getTempo());
                pstm.setInt(3, tf.getId());
                pstm.executeUpdate();
                
                
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Erro na edição \n" + ex );
            }finally{
                
                cn.closeConnection(cnx, pstm);
            }
    }
    
    //DELETA OS DADOS DA TABELA tbl_movimentacao CONFORME O ID RECEBIDO PELO MÉTODO.
    public void deletaDados(DadosEntrada tf){
       
        Connection cnx = cn.getConnection();
        PreparedStatement pstm = null;
            
            try {
                pstm = cnx.prepareStatement("DELETE FROM tbl_movimentacao WHERE ID = ?");
                pstm.setInt(1, tf.getId());
                pstm.executeUpdate();
                
                
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Erro ao excluir \n" + ex );
            }finally{
                
                cn.closeConnection(cnx, pstm);
            }
    }
}


        
    
    
    


 
   
